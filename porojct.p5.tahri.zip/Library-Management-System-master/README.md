Login information

For User =
username : user
password : 1234

For admin = 
username : admin
password : 1234
